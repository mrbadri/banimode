const Layout = () => {
    return ( 
        <div className="layout">
            test Layout
        </div>
     );
}
 
export default Layout;